<script>
	import NavBar from "./NavBar.svelte";
</script>

<main>
	<NavBar/>
</main>

<style></style>